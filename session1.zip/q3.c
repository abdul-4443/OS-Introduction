#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

int main(int argc, char *argv[]){
    int sum = 0;
    int temp;

    for(int i = 0; i < argc; i++){
        temp = atoi(argv[i]);
        sum += temp;
    }
    printf("Sum  = %d \n", sum);
    return 0;
}