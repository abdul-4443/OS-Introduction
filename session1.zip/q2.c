#include<limits.h>
#include<stdio.h>
#include<stdlib.h>
int main(){
    int size;
    printf("Enter the size of array: ");
    scanf("%d", &size);
    if(size <= 0){
        printf("Invalid input");
    }
    else{
        int largest = INT_MIN;
        int* arr = malloc(sizeof(int) * size);
        for(int i = 0; i < size; i++){
            printf("Enter the element at %d th index: ", i);
            scanf("%d", &arr[i]);
            if(arr[i] > largest) largest = arr[i];
        }
        printf("Largest = %d \n", largest);
    }
    
    return 0;
}