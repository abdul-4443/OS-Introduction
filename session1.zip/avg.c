#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include"functions.h"
float findAverage(int size, int* arr){
    int sum = 0;
    for(int i = 0; i < size; i++){
        sum += arr[i];
    }
    return sum / size;
}