#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
float findAverage(int size, int* arr);
int findMaximum(int size, int* arr);
int findMinimum(int size, int* arr);
#endif 