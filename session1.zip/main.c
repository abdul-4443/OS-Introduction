#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include"functions.h"

int main(){

    int size;
    printf("Enter the size of array: ");
    scanf("%d", &size);
    if(size <= 0){
        printf("Invalid input");
        return 0;
    }
    else{
        int* arr = malloc(sizeof(int) * size);
        for(int i = 0; i < size; i++){
            printf("Enter the element at %d th index: ", i);
            scanf("%d", &arr[i]);
        }
        int s = findMinimum(size, arr);
        printf("Smallest = %d \n", s);
        int l = findMaximum(size, arr);
        printf("Largest = %d \n", l);
        float a = findAverage(size, arr);
        printf("Average = %f \n", a);
    
    }
    return 0;
}