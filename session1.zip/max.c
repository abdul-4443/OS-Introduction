#include<stdio.h>
#include<stdlib.h>
#include"functions.h"
#include<limits.h>

int findMaximum(int size, int* arr){
    int largest = INT_MIN;
    for(int i = 0; i < size; i++){
        if(arr[i] > largest) largest = arr[i];
    }
    return largest;
}