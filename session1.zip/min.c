#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include"functions.h"
int findMinimum(int size, int* arr){
    int smallest = INT_MAX;
    for(int i = 0; i < size; i++){
        if(arr[i] < smallest) smallest = arr[i];
    }
    return smallest;
}